"""
Facebook Ads MCP Server
Connecte Claude à ton compte publicitaire Facebook/Meta
"""

import json
import os
import httpx
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict
from mcp.server.fastmcp import FastMCP

# ─── Config ───────────────────────────────────────────────────────────────────
ACCESS_TOKEN = os.environ.get("FB_ACCESS_TOKEN", "")
AD_ACCOUNT_ID = os.environ.get("FB_AD_ACCOUNT_ID", "")  # Format: act_XXXXXXXXX
API_VERSION = "v19.0"
BASE_URL = f"https://graph.facebook.com/{API_VERSION}"

mcp = FastMCP("facebook_ads_mcp")

# ─── Helper ───────────────────────────────────────────────────────────────────
async def fb_get(endpoint: str, params: dict = {}) -> dict:
    """Appel GET vers l'API Meta Graph."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{BASE_URL}/{endpoint}",
            params={"access_token": ACCESS_TOKEN, **params}
        )
        resp.raise_for_status()
        return resp.json()

def fmt_currency(value) -> str:
    """Convertit centimes → DZD lisible."""
    try:
        return f"{float(value)/100:,.0f} DZD"
    except:
        return str(value)

# ─── Models ───────────────────────────────────────────────────────────────────
class CampaignListInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: Optional[str] = Field(
        default="ACTIVE",
        description="Filtre statut: ACTIVE, PAUSED, ARCHIVED, ALL"
    )
    limit: Optional[int] = Field(default=10, ge=1, le=50)

class InsightsInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    object_id: str = Field(..., description="ID campagne, ad set ou ad")
    date_preset: Optional[str] = Field(
        default="last_7d",
        description="Période: today, yesterday, last_7d, last_30d, this_month, last_month"
    )

class AdSetListInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    campaign_id: str = Field(..., description="ID de la campagne")

class AdListInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    adset_id: str = Field(..., description="ID de l'ad set")

# ─── Tools ────────────────────────────────────────────────────────────────────

@mcp.tool(
    name="fb_list_campaigns",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def fb_list_campaigns(params: CampaignListInput) -> str:
    """Liste toutes les campagnes de ton compte pub Facebook.

    Retourne: nom, ID, statut, objectif, budget quotidien/total pour chaque campagne.
    """
    try:
        filter_status = [] if params.status == "ALL" else [params.status]
        query = {
            "fields": "id,name,status,objective,daily_budget,lifetime_budget,start_time,stop_time",
            "limit": params.limit,
        }
        if filter_status:
            query["effective_status"] = json.dumps(filter_status)

        data = await fb_get(f"{AD_ACCOUNT_ID}/campaigns", query)
        campaigns = data.get("data", [])

        if not campaigns:
            return "✅ Aucune campagne trouvée avec ce filtre."

        lines = [f"📊 **{len(campaigns)} campagne(s) trouvée(s)**\n"]
        for c in campaigns:
            budget = fmt_currency(c.get("daily_budget") or c.get("lifetime_budget", 0))
            budget_type = "Quotidien" if c.get("daily_budget") else "Total"
            lines.append(
                f"🎯 **{c['name']}**\n"
                f"   ID: `{c['id']}`\n"
                f"   Statut: {c.get('status')} | Objectif: {c.get('objective')}\n"
                f"   Budget {budget_type}: {budget}\n"
            )
        return "\n".join(lines)

    except httpx.HTTPStatusError as e:
        return f"❌ Erreur API Facebook: {e.response.status_code} — {e.response.text}"
    except Exception as e:
        return f"❌ Erreur: {str(e)}"


@mcp.tool(
    name="fb_get_insights",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def fb_get_insights(params: InsightsInput) -> str:
    """Récupère les stats de performance (Insights) d'une campagne, ad set ou publicité.

    Retourne: impressions, clics, CTR, CPM, dépenses, résultats (leads/messages), CPR, ROAS.
    """
    try:
        fields = ",".join([
            "impressions", "clicks", "ctr", "cpm", "cpp",
            "spend", "reach", "frequency",
            "actions", "cost_per_action_type",
            "purchase_roas", "unique_clicks"
        ])
        data = await fb_get(f"{params.object_id}/insights", {
            "fields": fields,
            "date_preset": params.date_preset,
            "level": "account"
        })

        insights = data.get("data", [])
        if not insights:
            return f"ℹ️ Pas de données pour la période `{params.date_preset}`."

        i = insights[0]
        spend = float(i.get("spend", 0))

        # Extraire leads/messages depuis actions
        actions = {a["action_type"]: float(a["value"]) for a in i.get("actions", [])}
        leads = actions.get("lead", actions.get("onsite_conversion.lead_grouped", 0))
        messages = actions.get("onsite_conversion.messaging_conversation_started_7d", 0)
        cpl = spend / leads if leads > 0 else 0
        cpm = actions.get("onsite_conversion.messaging_first_reply", 0)

        lines = [
            f"📈 **Insights — {params.date_preset}**\n",
            f"💰 Dépenses:      {spend:.2f} $",
            f"👁️  Impressions:   {int(i.get('impressions', 0)):,}",
            f"📢 Portée:        {int(i.get('reach', 0)):,}",
            f"🖱️  Clics:         {int(i.get('clicks', 0)):,}",
            f"📊 CTR:           {float(i.get('ctr', 0)):.2f}%",
            f"💵 CPM:           {float(i.get('cpm', 0)):.2f} $",
            f"🔁 Fréquence:     {float(i.get('frequency', 0)):.2f}",
            f"\n📬 Leads:         {leads:.0f}",
            f"💬 Messages:      {messages:.0f}",
            f"🎯 CPL:           {cpl:.2f} $" if leads > 0 else "",
        ]

        roas_data = i.get("purchase_roas", [])
        if roas_data:
            roas = float(roas_data[0].get("value", 0))
            lines.append(f"🚀 ROAS:          {roas:.2f}x")

        return "\n".join(l for l in lines if l)

    except httpx.HTTPStatusError as e:
        return f"❌ Erreur API Facebook: {e.response.status_code} — {e.response.text}"
    except Exception as e:
        return f"❌ Erreur: {str(e)}"


@mcp.tool(
    name="fb_list_adsets",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def fb_list_adsets(params: AdSetListInput) -> str:
    """Liste les ad sets d'une campagne avec leur budget, statut et ciblage."""
    try:
        data = await fb_get(f"{params.campaign_id}/adsets", {
            "fields": "id,name,status,daily_budget,lifetime_budget,targeting,optimization_goal,billing_event",
            "limit": 20
        })
        adsets = data.get("data", [])
        if not adsets:
            return "✅ Aucun ad set trouvé."

        lines = [f"🗂️ **{len(adsets)} Ad Set(s)**\n"]
        for a in adsets:
            budget = fmt_currency(a.get("daily_budget") or a.get("lifetime_budget", 0))
            targeting = a.get("targeting", {})
            ages = f"{targeting.get('age_min', '?')}–{targeting.get('age_max', '?')} ans"
            lines.append(
                f"📁 **{a['name']}**\n"
                f"   ID: `{a['id']}` | Statut: {a.get('status')}\n"
                f"   Budget: {budget} | Optimisation: {a.get('optimization_goal')}\n"
                f"   Âge: {ages}\n"
            )
        return "\n".join(lines)

    except httpx.HTTPStatusError as e:
        return f"❌ Erreur API: {e.response.status_code}"
    except Exception as e:
        return f"❌ Erreur: {str(e)}"


@mcp.tool(
    name="fb_account_summary",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def fb_account_summary(_: dict = {}) -> str:
    """Résumé global du compte publicitaire: dépenses totales, campagnes actives, solde."""
    try:
        data = await fb_get(AD_ACCOUNT_ID, {
            "fields": "name,account_status,currency,amount_spent,balance,spend_cap"
        })
        status_map = {1: "✅ Actif", 2: "⛔ Désactivé", 3: "⚠️ Non confirmé", 9: "🔒 Fermé"}
        status = status_map.get(data.get("account_status"), "❓ Inconnu")

        return (
            f"🏢 **{data.get('name', 'Compte Pub')}**\n\n"
            f"📌 Statut:         {status}\n"
            f"💱 Devise:         {data.get('currency')}\n"
            f"💸 Total dépensé:  {float(data.get('amount_spent', 0))/100:.2f} {data.get('currency')}\n"
            f"💰 Solde:          {float(data.get('balance', 0))/100:.2f} {data.get('currency')}\n"
        )

    except httpx.HTTPStatusError as e:
        return f"❌ Erreur API: {e.response.status_code} — {e.response.text}"
    except Exception as e:
        return f"❌ Erreur: {str(e)}"


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    mcp.run(transport="streamable_http", port=port)
