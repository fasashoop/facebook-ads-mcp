# Facebook Ads MCP Server 🚀

Connecte Claude à ton compte publicitaire Facebook/Meta via le protocole MCP.

## 🛠️ Outils disponibles

| Outil | Description |
|-------|-------------|
| `fb_account_summary` | Résumé global du compte (solde, dépenses, statut) |
| `fb_list_campaigns` | Liste toutes tes campagnes avec budget et statut |
| `fb_get_insights` | Stats de performance (CTR, CPM, leads, ROAS...) |
| `fb_list_adsets` | Liste les ad sets d'une campagne |

---

## 🔑 Variables d'environnement requises

```
FB_ACCESS_TOKEN=EAAxxxxxxxx...   # Token d'accès Facebook
FB_AD_ACCOUNT_ID=act_61566276373425  # ID du compte pub (avec "act_")
PORT=8000
```

---

## 🚀 Déploiement gratuit sur Railway

1. Va sur [railway.app](https://railway.app) → New Project → Deploy from GitHub
2. Upload ce dossier sur un repo GitHub
3. Dans Railway → **Variables** → ajoute :
   - `FB_ACCESS_TOKEN` = ton token
   - `FB_AD_ACCOUNT_ID` = `act_61566276373425`
4. Une fois déployé, copie l'URL publique (ex: `https://ton-app.up.railway.app`)

---

## 🔗 Connexion dans Claude

1. Ouvre Claude → Settings → Connectors
2. Clique "Ajouter un connecteur personnalisé"
3. **URL MCP** = `https://ton-app.up.railway.app/mcp`
4. Clique "Ajouter"

---

## 🔑 Comment obtenir ton Access Token Facebook

1. Va sur [developers.facebook.com](https://developers.facebook.com)
2. Crée une application (type: Business)
3. Ajoute le produit **Marketing API**
4. Dans **Graph API Explorer** → génère un token avec les permissions :
   - `ads_read`
   - `ads_management`
   - `business_management`
5. **Pour un token longue durée** (60 jours), utilise :
   ```
   https://graph.facebook.com/v19.0/oauth/access_token?grant_type=fb_exchange_token&client_id=APP_ID&client_secret=APP_SECRET&fb_exchange_token=SHORT_TOKEN
   ```

---

## 💬 Exemple de questions à poser à Claude

> "Montre-moi les stats de mes campagnes actives cette semaine"
> "Quelle campagne a le meilleur ROAS ce mois-ci ?"
> "Quel est mon solde et combien j'ai dépensé ?"
> "Liste les ad sets de la campagne [ID]"
